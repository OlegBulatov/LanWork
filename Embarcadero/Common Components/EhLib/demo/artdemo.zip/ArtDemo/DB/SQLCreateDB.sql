/****** http://www.delphikingdom.ru/helloworld/ado02.htm ******/
/****** Object:  Table [dbo].[Abonents]    Script Date: 18.05.2001 13:08:09 ******/
CREATE TABLE [dbo].[Abonents] (
	[AbonentID] [int] IDENTITY (1, 1) NOT NULL ,
	[AbonentName] [nvarchar] (50) NOT NULL ,
	[Phone] [nvarchar] (15) NULL ,
	[Code] [nvarchar] (3) NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Calls]    Script Date: 18.05.2001 13:08:11 ******/
CREATE TABLE [dbo].[Calls] (
	[CallID] [int] IDENTITY (1, 1) NOT NULL ,
	[AbonentID] [int] NOT NULL ,
	[DateTime] [smalldatetime] NULL ,
	[Duration] [int] NOT NULL ,
	[CalledCode] [nvarchar] (10) NULL ,
	[CalledNumber] [nvarchar] (50) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Abonents] WITH NOCHECK ADD 
	CONSTRAINT [DF_Abonents_Code] DEFAULT (8) FOR [Code],
	CONSTRAINT [PK_Abonents] PRIMARY KEY  NONCLUSTERED 
	(
		[AbonentID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Calls] WITH NOCHECK ADD 
	CONSTRAINT [PK_Calls] PRIMARY KEY  NONCLUSTERED 
	(
		[CallID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Calls] ADD 
	CONSTRAINT [FK_Calls_Abonents] FOREIGN KEY 
	(
		[AbonentID]
	) REFERENCES [dbo].[Abonents] (
		[AbonentID]
	)
GO

